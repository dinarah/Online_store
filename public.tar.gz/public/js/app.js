var app = angular.module('OnlineShop', ['ui.router', "store", "myApp", 'ngCart']);

app.config(function ($stateProvider, $urlRouterProvider) {

  $urlRouterProvider.otherwise('#/home');

  $stateProvider
    .state('home', {
      url: '/home',
      templateUrl: 'partials/home.html'
    })
    .state('shop', {
      url: '/shop',
      templateUrl: 'partials/shop.html'
    })
    .state('customercare', {
      url: '/customercare',
      templateUrl: 'partials/customercare.html'
    })
    .state('blog', {
      url: '/blog',
      templateUrl: 'partials/blog.html'
    })
    .state('aboutus', {
      url: '/aboutus',
      templateUrl: 'partials/aboutus.html'
    })
   .state('store', {
      url: '/store',
      templateUrl: 'partials/store.html'
    })
  .state('product', {
      url: '/product',
      templateUrl: 'partials/product.html',
 
    })
});


app.controller('TabController', function() {
  this.tab = 1;

  this.selectTab = function(setTab) {
    this.tab = setTab;
  };

  this.isSelected = function(checkTab) {
    return this.tab === checkTab;
  };
});
