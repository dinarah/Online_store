var storeApp = angular.module('store', []);

storeApp.controller('StoreController', ['$http', function ($http) {
      var store = this;
      store.items = [];
      $http.get('/items').success(function(data) {
        data = _.chunk(data, 4);
        store.items = data;
      });
}]);

var jeweleries = [
  {
      name: 'Valerie',
      price: 14.99,
      description: 'This is our new brand',
      canPurchase: true,
      images: [
          {
              full: 'images/download.jpg',
          }]
  },
  {
      name: 'Lala',
      price: 15.99,
      description: 'This is what we can offer to you',
      canPurchase: true,
       images: [
          {
              full: 'images/download.jpg',
          }]
  },
     {
      name: 'Nora',
      price: 16.99,
      description: '',
      canPurchase: true,
          images: [
          {
              full: 'images/download.jpg',
          }]
  },
     {
      name: 'Susanne',
      price: 17.99,
      description: 'This is what we can offer to you',
      canPurchase: true,
          images: [
          {
              full: 'images/download.jpg',
          }]
  },
{
      name: 'Julia',
      price: 18.99,
      description: 'This is what we can offer to you',
      canPurchase: true,
          images: [
          {
              full: 'images/download.jpg',
          }]
},
    {
      name: 'Tina',
      price: 20.99,
      description: 'This is what we can offer to you',
      canPurchase: true,
          images: [
          {
              full: 'images/download.jpg',
          }]
    },
    {
      name: 'Nina',
      price: 21.99,
      description: 'This is what we can offer to you',
      canPurchase: true,
          images: [
          {
              full: 'images/download.jpg',
          }]
    },
    {
      name: 'Lara',
      price: 22.99,
      description: 'This is what we can offer to you',
      canPurchase: true,
          images: [
          {
              full: 'images/download.jpg',
          }]
    }

    ];

var myApp = angular.module('myApp',['ngCart']);

myApp.controller ('myCtrl', ['$scope', '$http', 'ngCart', function($scope, $http, ngCart) {
    ngCart.setTaxRate(0);
    ngCart.setShipping(0);

}]);
